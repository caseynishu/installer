#!/bin/bash
if [ ! -f $1.conf ]; then
echo "Can't find $1.conf"
exit
fi

cp $1.conf /tmp
grep UID /etc/weaved/services/$1.conf >> /tmp/$1.conf
grep password /etc/weaved/services/$1.conf >> /tmp/$1.conf
mv /tmp/$1.conf /etc/weaved/services
$1.sh restart
