#! /bin/sh
Weavedssh22.sh stop
Weavedrmt3-65535.sh stop
Weavedsch.sh stop
Weavedhttp80.sh stop
Weavedhttp8080.sh stop
