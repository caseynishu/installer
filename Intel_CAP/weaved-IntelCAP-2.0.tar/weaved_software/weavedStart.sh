#! /bin/sh
Weavedrmt3-65535.sh restart
Weavedssh22.sh restart
Weavedhttp80.sh restart
Weavedhttp8080.sh restart
Weavedsch.sh restart
