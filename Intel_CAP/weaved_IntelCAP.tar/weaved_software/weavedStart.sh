#! /bin/sh
Weavedssh22.sh start
Weavedhttp80.sh start
Weavedhttp8080.sh start
