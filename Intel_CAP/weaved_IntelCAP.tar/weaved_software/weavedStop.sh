#! /bin/sh
Weavedssh22.sh stop
Weavedhttp80.sh stop
Weavedhttp8080.sh stop
